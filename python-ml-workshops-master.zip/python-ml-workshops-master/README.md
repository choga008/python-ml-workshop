# Python ML Workshops
Information and links to materials for the Python Machine Learning Workshop series.

- [2019-01-07 Workshop](https://github.com/womenindatascienceatx/python_ml_20190117/blob/master/README.md)
- [2020-02-24 Workshop](https://github.com/womenindatascienceatx/python-ml-workshops/blob/master/python_ml_20200224/README.md)
